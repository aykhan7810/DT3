#include "audioport.h"

#if defined(MTI_SYSTEMC)
SC_MODULE_EXPORT(audioport);
#endif


#if defined(XMSC)
XMSC_MODULE_EXPORT(audioport)
#endif
